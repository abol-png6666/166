"""Cloudflare quick-tunnel for serving >49MB files as direct download links."""
import asyncio
import hashlib
import logging
import os
import re
import shutil
import time

from aiohttp import web

import config

log = logging.getLogger("tunnel")
_url = None
_proc = None


def file_app():
    app = web.Application()
    app.router.add_get("/dl/{name}", _dl)
    return app


async def _dl(request):
    name = os.path.basename(request.match_info["name"])
    p = os.path.join(config.FILE_DIR, name)
    if not os.path.exists(p):
        return web.Response(status=404, text="not found")
    return web.FileResponse(
        p, headers={"Content-Disposition": f'attachment; filename="{name}"'})


async def get_tunnel_url():
    global _url, _proc
    if _url:
        return _url
    exe = shutil.which("cloudflared")
    if not exe and os.path.exists("cloudflared"):
        exe = os.path.abspath("cloudflared")
    if not exe:
        log.warning("cloudflared not found")
        return None
    try:
        _proc = await asyncio.create_subprocess_exec(
            exe, "tunnel", "--url", f"http://127.0.0.1:{config.FILE_PORT}",
            "--no-autoupdate",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT)
        for _ in range(80):
            line = await asyncio.wait_for(_proc.stdout.readline(), 5)
            if not line:
                break
            m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com",
                          line.decode("utf8", "ignore"))
            if m:
                _url = m.group(0)
                log.info("tunnel up: %s", _url)
                break
    except Exception as e:
        log.warning("tunnel failed: %s", e)
    return _url


async def publish_file(path, hint="file"):
    """Copy to public dir and return direct URL via tunnel (or None)."""
    name = f"{hashlib.sha1((path + str(time.time())).encode()).hexdigest()[:10]}_{os.path.basename(path)}"
    dst = os.path.join(config.FILE_DIR, name)
    if not os.path.exists(dst):
        shutil.copy2(path, dst)
    url = await get_tunnel_url()
    return f"{url}/dl/{name}" if url else None
