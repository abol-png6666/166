"""Offline debug test-suite for SpaceWatch Bot. Run: python test_run.py"""
import asyncio
import time
import os
import shutil
import sys
import tempfile

TMP = tempfile.mkdtemp(prefix="swtest_")
import config  # noqa: E402
config.IMG_DIR = os.path.join(TMP, "images")
config.FILE_DIR = os.path.join(TMP, "files")
config.DB_PATH = os.path.join(TMP, "bot.db")

PASS, FAIL = 0, 0


def check(name, cond):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✅ {name}")
    else:
        FAIL += 1
        print(f"  ❌ {name}")


print("== 1) imports ==")
try:
    import database as db
    import repair
    import i18n
    import sources
    import tunnel
    import webui
    import bot
    import main  # noqa
    check("all modules import", True)
except Exception as e:
    check(f"all modules import ({e})", False)
    sys.exit(1)

print("== 2) database ==")
db.init()
db.setcfg("bot_token", "x")
check("cfg set/get", db.cfg("bot_token") == "x")
db.ensure_user(123)
db.set_user_lang(123, "en")
check("user lang", db.get_user_lang(123) == "en")
img_id = db.insert_image(dict(src="t", url="http://x", hash="h1", path="/tmp/a.jpg",
                              region="ایران — مرکز تصویر (32.0°, 53.0°)", cc="IR",
                              lat=32.0, lon=53.0, sat="EPIC", img_time=100.0,
                              fetched_at=1000.0, status="complete", width=10,
                              height=10, size=100))
check("insert + exists", db.image_exists("h1"))
check("get_image", db.get_image(img_id)["sat"] == "EPIC")
check("images_since", len(db.images_since(0)) == 1)
check("find_region iran", db.find_region("iran")["id"] == img_id)
check("find_region IR cc", db.find_region("IR")["id"] == img_id)
db.insert_image(dict(src="t2", url="http://y", hash="h2", path="/tmp/b.jpg",
                     region="sun", cc="", sat="SDO", img_time=time.time(), fetched_at=time.time(),
                     status="partial", width=1, height=1, size=1))
check("partials_due", len(db.partials_due()) == 1)
u, i, p = db.counts()
check("counts", (u, i, p) == (1, 2, 1))

print("== 3) repair (OpenCV) ==")
import cv2
import numpy as np
ok_img = np.random.randint(0, 255, (300, 300, 3), np.uint8)
p_ok = os.path.join(TMP, "ok.jpg")
cv2.imwrite(p_ok, ok_img)
check("complete img not partial", repair.detect_partial(p_ok) is False)
part = np.random.randint(0, 255, (300, 300, 3), np.uint8)
part[200:, :] = 128  # flat trailing band = partially received
p_bad = os.path.join(TMP, "bad.jpg")
cv2.imwrite(p_bad, part)
check("partial img detected", repair.detect_partial(p_bad) is True)
rep = repair.try_repair(p_bad)
check("repair output exists", bool(rep) and os.path.exists(rep))

print("== 4) i18n ==")
core = ["welcome", "help", "cap_title", "region", "time", "delay", "sat",
        "quality", "status", "orig_btn", "rep_btn", "info_btn"]
for code, _, _ in i18n.LANGS:
    missing = [k for k in core if not i18n.tr(code, k)]
    check(f"lang {code} core keys", not missing)
check("10 langs", len(i18n.LANGS) == 10)

print("== 5) bot parsing ==")
m = bot.HIST_RE.search("/history 6H")
check("history 6H", m and (m.group(1), m.group(2).lower()) == ("6", "h"))
m = bot.HIST_RE.search("/history 2D")
check("history 2D", m and (m.group(1), m.group(2).lower()) == ("2", "d"))
m = bot.HIST_RE.search("/history 30m")
check("history 30m", m and (m.group(1), m.group(2).lower()) == ("30", "m"))
check("history units", bot.UNITS == {"m": 60, "h": 3600, "d": 86400})
row = db.get_image(img_id)
cap = bot.caption_for(row, "fa")
check("caption fa", "تصویر جدید" in cap and "ایران" in cap and "EPIC" in cap)
cap_en = bot.caption_for(row, "en")
check("caption en", "New image" in cap_en)
kb = bot.glass_buttons(img_id, "fa")
check("glass buttons", len(kb.inline_keyboard[0]) == 3)
check("fmt_uptime", bot.fmt_uptime(3600 * 5, "en") == "5H")

print("== 6) webui ==")
class _Mgr:
    running = False
app = webui.make_app(_Mgr())
check("webui app routes", len(app.router.routes()) >= 7)
check("html has theme+lang", "toggleTheme" in webui.HTML and "toggleLang" in webui.HTML)

print("== 7) sources parsing ==")
import feedparser
feed_xml = """<?xml version='1.0'?><rss version='2.0'><channel><item>
<title>Test Nebula</title><link>http://x</link>
<description>&lt;img src="https://cdn.example.com/big.jpg"/&gt;</description>
</item></channel></rss>"""
parsed = feedparser.parse(feed_xml)
check("feed entry image regex",
      sources._entry_image(parsed.entries[0]) == "https://cdn.example.com/big.jpg")
check("himawari url fmt", sources.HIMA_IMG.format(y="2026", m="09", d="05", hm="120000")
      .endswith("/2026/09/05/120000_0_0.png"))

print("== 8) zip builder (for /all) ==")
zpath = asyncio.get_event_loop().run_until_complete(asyncio.to_thread(bot._build_zip))
import zipfile
check("zip built", os.path.getsize(zpath) > 0 and zipfile.is_zipfile(zpath))

print("== 9) live source reachability (optional) ==")
async def live():
    import aiohttp
    out = {}
    async with aiohttp.ClientSession() as s:
        tests = {
            "SDO": "https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0193.jpg",
            "GOES": "https://cdn.star.nesdis.noaa.gov/GOES19/ABI/FD/GEOCOLOR/1808x1808.jpg",
            "EPIC api": "https://epic.gsfc.nasa.gov/api/natural",
            "Himawari json": "https://himawari8-dl.nict.go.jp/himawari8/img/D531106/latest.json",
        }
        for name, url in tests.items():
            try:
                async with s.get(url, timeout=aiohttp.ClientTimeout(total=20)) as r:
                    body = await r.read()
                    out[name] = (r.status, len(body))
            except Exception as e:
                out[name] = ("ERR", str(e)[:60])
    return out
try:
    res = asyncio.get_event_loop().run_until_complete(live())
    for k, v in res.items():
        ok = isinstance(v[0], int) and v[0] == 200
        check(f"live {k} -> {v}", ok)
except Exception as e:
    print(f"  ⚠️ live tests skipped ({e})")

shutil.rmtree(TMP, ignore_errors=True)
print(f"\n===== RESULT: {PASS} passed, {FAIL} failed =====")
sys.exit(1 if FAIL else 0)
