"""OpenCV-based partial-image detection + lightweight inpainting repair."""
import logging

import cv2
import numpy as np

log = logging.getLogger("repair")


def detect_partial(path):
    """Heuristic: partially-received satellite images have big uniform
    (flat) trailing bands at the bottom or right side."""
    try:
        img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            return True
        rs = img.std(axis=1)
        cs = img.std(axis=0)
        n = len(rs)
        tail_bad = (rs[int(n * 0.6):] < 2.0).mean() > 0.65
        head_ok = (rs[:max(1, int(n * 0.45))] > 4).mean() > 0.4
        right_bad = (cs[int(len(cs) * 0.85):] < 1.5).mean() > 0.9
        return bool((tail_bad and head_ok) or right_bad)
    except Exception as e:
        log.warning("detect_partial error: %s", e)
        return False


def try_repair(path):
    """Inpaint the flat/uniform bands. Returns repaired file path or None.
    Skips when the damaged area is too large (would be too heavy / ugly)."""
    try:
        img = cv2.imread(path)
        if img is None:
            return None
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        mask = np.zeros(gray.shape, np.uint8)

        rs = gray.std(axis=1)
        bad_rows = np.where(rs < 1.5)[0]
        # only treat as damage when flat rows form a trailing block
        if len(bad_rows) > 8 and bad_rows.max() >= gray.shape[0] - 2:
            start = bad_rows[0]
            if start > gray.shape[0] * 0.3:
                mask[start:, :] = 255

        cs = gray.std(axis=0)
        bad_cols = np.where(cs < 1.5)[0]
        if len(bad_cols) > 8 and bad_cols.max() >= gray.shape[1] - 2:
            start = bad_cols[0]
            if start > gray.shape[1] * 0.3:
                mask[:, start:] = 255

        frac = (mask > 0).mean()
        if frac == 0:
            return None
        if frac > 0.35:
            log.info("damage too large (%.0f%%) -> skip repair", frac * 100)
            return None

        mask = cv2.dilate(mask, np.ones((3, 3), np.uint8))
        repaired = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
        out = path.rsplit('.', 1)[0] + "_repaired.jpg"
        cv2.imwrite(out, repaired, [cv2.IMWRITE_JPEG_QUALITY, 95])
        return out
    except Exception as e:
        log.warning("repair failed: %s", e)
        return None
