"""Web control panel on :8080 — FA/EN, dark/light (monochrome glass)."""
import logging
import time

import aiohttp
from aiohttp import web

import database as db
from bot import broadcast_text

log = logging.getLogger("webui")

HTML = r"""<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>🛰️ SpaceWatch Bot</title>
<style>
:root{--bg:#0a0a0a;--fg:#f2f2f2;--card:rgba(255,255,255,.06);--border:rgba(255,255,255,.18)}
body.light{--bg:#f4f4f4;--fg:#111;--card:rgba(0,0,0,.05);--border:rgba(0,0,0,.15)}
*{box-sizing:border-box;font-family:Tahoma,Vazirmatn,system-ui,sans-serif}
body{margin:0;background:var(--bg);color:var(--fg);min-height:100vh;transition:.3s}
header{display:flex;justify-content:space-between;align-items:center;padding:14px 22px;border-bottom:1px solid var(--border)}
h1{font-size:19px;margin:0}
.wrap{max-width:720px;margin:22px auto;padding:0 14px}
.card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:20px;margin-bottom:14px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px)}
button{background:rgba(255,255,255,.10);border:1px solid var(--border);color:var(--fg);padding:10px 18px;border-radius:12px;cursor:pointer;backdrop-filter:blur(8px);font-size:14px}
body.light button{background:rgba(0,0,0,.06)}
button:hover{filter:brightness(1.25)}
input,textarea{width:100%;padding:12px;border-radius:12px;border:1px solid var(--border);background:transparent;color:var(--fg);margin:6px 0;font-size:14px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px}
.stat{text-align:center;padding:12px;border:1px solid var(--border);border-radius:12px}
.stat b{font-size:22px;display:block}
.small{opacity:.65;font-size:13px}
.msg{margin-top:8px;font-size:13px}
</style></head><body>
<header><h1>🛰️ <span id="t-title"></span></h1>
<div><button onclick="toggleTheme()" id="thBtn">🌙</button>
<button onclick="toggleLang()" id="lgBtn">EN</button></div></header>
<div class="wrap" id="app"><div class="card small">loading…</div></div>
<script>
let L = localStorage.lang || 'fa';
const S = {
fa:{title:'پنل بات رصد فضا',setup:'راه‌اندازی اولیه',token:'توکن بات تلگرام (از BotFather)',admin:'آیدی عددی ادمین',save:'ذخیره و شروع 🚀',status:'وضعیت بات',running:'🟢 در حال اجرا',stopped:'⚫ خاموش',start:'روشن کردن',stop:'خاموش کردن',pub:'حالت عمومی',pub_on:'🌍 عمومی — روشن (برای همه ارسال می‌شود)',pub_off:'🔒 عمومی — خاموش (فقط ادمین)',bc:'پیام همگانی به همه کاربران',send:'ارسال 📣',users:'کاربران',imgs:'تصاویر جمع‌شده',part:'تصاویر ناقص',up:'آپتایم',ok:'انجام شد ✅',err:'خطا! دوباره تلاش کن',login:'ورود مدیر',login_btn:'ورود',login_hint:'آیدی عددی ادمین را وارد کن'},
en:{title:'SpaceWatch Bot Panel',setup:'First-time setup',token:'Telegram bot token (from BotFather)',admin:'Admin numeric ID',save:'Save & Start 🚀',status:'Bot status',running:'🟢 Running',stopped:'⚫ Stopped',start:'Start',stop:'Stop',pub:'Public mode',pub_on:'🌍 Public — ON (everyone gets images)',pub_off:'🔒 Public — OFF (admin only)',bc:'Broadcast message to all users',send:'Send 📣',users:'Users',imgs:'Images',part:'Partial',up:'Uptime',ok:'Done ✅',err:'Error! Try again',login:'Admin login',login_btn:'Login',login_hint:'Enter admin numeric ID'}
};
function t(k){return S[L][k]||k}
function applyLang(){
  document.documentElement.lang=L;
  document.documentElement.dir=(L==='fa'||L==='ar')?'rtl':'ltr';
  document.getElementById('t-title').textContent=t('title');
  document.getElementById('lgBtn').textContent=(L==='fa'?'EN':'FA');
}
function toggleLang(){L=(L==='fa'?'en':'fa');localStorage.lang=L;applyLang();render(lastState)}
function toggleTheme(){document.body.classList.toggle('light');document.getElementById('thBtn').textContent=document.body.classList.contains('light')?'☀️':'🌙';localStorage.theme=document.body.classList.contains('light')?'l':'d'}
if(localStorage.theme==='l'){document.body.classList.add('light')}
let lastState=null;
function fmtUp(s){s=Math.floor(s);if(s<3600)return Math.floor(s/60)+'m';if(s<172800)return Math.floor(s/3600)+'h';return Math.floor(s/86400)+'d'}
async function post(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});return r.json()}
async function doSetup(){const r=await post('/setup',{token:v('token'),admin_id:v('admin')});msg('smsg',r.ok?t('ok'):t('err'));if(r.ok)setTimeout(load,600)}
async function doLogin(){const r=await post('/api/login',{admin_id:v('loginid')});msg('lmsg',r.ok?t('ok'):t('err'));if(r.ok)setTimeout(load,500)}
async function botCtl(a){await post('/api/bot',{action:a});setTimeout(load,700)}
async function pubCtl(){await post('/api/public',{});setTimeout(load,700)}
async function doBc(){const r=await post('/api/broadcast',{text:v('bctext')});msg('bmsg',r.ok?t('ok'):t('err'))}
function v(id){return document.getElementById(id).value}
function msg(id,txt){const e=document.getElementById(id);if(e)e.textContent=txt}
function render(st){
  const app=document.getElementById('app');
  if(!st.configured){app.innerHTML=`<div class="card"><h3>${t('setup')}</h3>
    <input id="token" placeholder="${t('token')}">
    <input id="admin" placeholder="${t('admin')}">
    <button onclick="doSetup()">${t('save')}</button><div class="msg" id="smsg"></div></div>`;return}
  if(!st.admin){app.innerHTML=`<div class="card"><h3>${t('login')}</h3>
    <input id="loginid" placeholder="${t('login_hint')}">
    <button onclick="doLogin()">${t('login_btn')}</button><div class="msg" id="lmsg"></div></div>`;return}
  app.innerHTML=`
  <div class="card"><h3>${t('status')}: ${st.running?t('running'):t('stopped')}</h3>
    <button onclick="botCtl('${st.running?'stop':'start'}')">${st.running?t('stop'):t('start')}</button></div>
  <div class="card"><h3>${t('pub')}</h3>
    <button onclick="pubCtl()">${st.public?t('pub_on'):t('pub_off')}</button>
    <div class="small">${st.public?t('pub_on'):t('pub_off')}</div></div>
  <div class="card"><div class="grid">
    <div class="stat"><b>${st.users}</b>${t('users')}</div>
    <div class="stat"><b>${st.images}</b>${t('imgs')}</div>
    <div class="stat"><b>${st.partial}</b>${t('part')}</div>
    <div class="stat"><b>${fmtUp(st.uptime)}</b>${t('up')}</div></div></div>
  <div class="card"><h3>${t('bc')}</h3>
    <textarea id="bctext" rows="3"></textarea>
    <button onclick="doBc()">${t('send')}</button><div class="msg" id="bmsg"></div></div>`;
}
async function load(){try{const r=await fetch('/api/state');lastState=await r.json();render(lastState)}catch(e){}}
applyLang();load();setInterval(load,4000);
</script></body></html>"""


def _authed(request):
    return request.cookies.get("uid") == (db.cfg("admin_id") or "__none__")


async def index(request):
    return web.Response(text=HTML, content_type="text/html")


async def setup(request):
    if db.cfg("bot_token"):
        return web.json_response({"ok": False, "error": "already configured"})
    data = await request.json()
    token = (data.get("token") or "").strip()
    admin_id = (data.get("admin_id") or "").strip()
    if not token or not admin_id.isdigit():
        return web.json_response({"ok": False, "error": "bad input"})
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.telegram.org/bot{token}/getMe",
                             timeout=aiohttp.ClientTimeout(total=15)) as r:
                j = await r.json()
                if not j.get("ok"):
                    return web.json_response({"ok": False, "error": "bad token"})
    except Exception as e:
        return web.json_response({"ok": False, "error": str(e)})
    db.setcfg("bot_token", token)
    db.setcfg("admin_id", admin_id)
    db.ensure_user(int(admin_id))
    resp = web.json_response({"ok": True})
    resp.set_cookie("uid", admin_id, max_age=30 * 24 * 3600)
    try:
        await request.app["mgr"].start()
    except Exception as e:
        log.warning("autostart after setup failed: %s", e)
    return resp


async def login(request):
    data = await request.json()
    if (data.get("admin_id") or "").strip() == (db.cfg("admin_id") or ""):
        resp = web.json_response({"ok": True})
        resp.set_cookie("uid", db.cfg("admin_id"), max_age=30 * 24 * 3600)
        return resp
    return web.json_response({"ok": False})


async def state(request):
    users, images, partial = db.counts()
    first_run = float(db.cfg("first_run") or time.time())
    return web.json_response({
        "configured": bool(db.cfg("bot_token")),
        "admin": _authed(request),
        "running": request.app["mgr"].running,
        "public": db.cfg("public", "0") == "1",
        "users": users, "images": images, "partial": partial,
        "uptime": time.time() - first_run,
    })


async def bot_ctl(request):
    if not _authed(request):
        return web.json_response({"ok": False}, status=403)
    data = await request.json()
    mgr = request.app["mgr"]
    try:
        if data.get("action") == "start":
            ok = await mgr.start()
        else:
            await mgr.stop()
            ok = True
        return web.json_response({"ok": ok})
    except Exception as e:
        return web.json_response({"ok": False, "error": str(e)})


async def public_ctl(request):
    if not _authed(request):
        return web.json_response({"ok": False}, status=403)
    cur = db.cfg("public", "0") == "1"
    db.setcfg("public", "0" if cur else "1")
    return web.json_response({"ok": True, "public": not cur})


async def broadcast_ctl(request):
    if not _authed(request):
        return web.json_response({"ok": False}, status=403)
    mgr = request.app["mgr"]
    if not mgr.running:
        return web.json_response({"ok": False, "error": "bot stopped"})
    data = await request.json()
    text = (data.get("text") or "").strip()
    if not text:
        return web.json_response({"ok": False})
    n = await broadcast_text(mgr.app.bot, text)
    return web.json_response({"ok": True, "sent": n})


def make_app(mgr):
    app = web.Application()
    app["mgr"] = mgr
    app.router.add_get("/", index)
    app.router.add_post("/setup", setup)
    app.router.add_post("/api/login", login)
    app.router.add_get("/api/state", state)
    app.router.add_post("/api/bot", bot_ctl)
    app.router.add_post("/api/public", public_ctl)
    app.router.add_post("/api/broadcast", broadcast_ctl)
    return app
