"""Polling of official public satellite/telescope image sources."""
import asyncio
import calendar
import hashlib
import io
import logging
import os
import re
import time
from email.utils import parsedate_to_datetime

import aiohttp
from PIL import Image

import config
import database as db
from repair import detect_partial, try_repair

log = logging.getLogger("sources")
UA = {"User-Agent": "SpaceWatchBot/1.0 (+official public imagery)"}

# --- Direct "latest image" URLs (official CDNs) -----------------------------
STATIC_SOURCES = [
    dict(key="goes19_fd", sat="GOES-19 (East) / NOAA",
         url="https://cdn.star.nesdis.noaa.gov/GOES19/ABI/FD/GEOCOLOR/1808x1808.jpg",
         region="نیمکره غربی — آمریکا و اقیانوس اطلس", cc="US"),
    dict(key="goes18_fd", sat="GOES-18 (West) / NOAA",
         url="https://cdn.star.nesdis.noaa.gov/GOES18/ABI/FD/GEOCOLOR/1808x1808.jpg",
         region="اقیانوس آرام — غرب آمریکا", cc="US"),
    dict(key="sdo_193", sat="SDO / NASA (AIA 193Å)",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0193.jpg",
         region="خورشید — تاج خورشید", cc=""),
    dict(key="sdo_304", sat="SDO / NASA (AIA 304Å)",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0304.jpg",
         region="خورشید — کروموسفر", cc=""),
    dict(key="sdo_hmi", sat="SDO / NASA (HMI)",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_HMII.jpg",
         region="خورشید — فتوسفر (لکه‌های خورشیدی)", cc=""),
    dict(key="soho_eit304", sat="SOHO / NASA-ESA (EIT 304)",
         url="https://soho.nascom.nasa.gov/data/realtime/eit_304/512/latest.jpg",
         region="خورشید", cc=""),
    dict(key="meteosat_iodc", sat="Meteosat (MSG) / EUMETSAT",
         url=("https://view.eumetsat.int/geoserver/wms?service=WMS&version=1.3.0"
              "&request=GetMap&layers=msg_fes%3Argb_natural&styles=&format=image%2Fjpeg"
              "&crs=EPSG%3A4326&bbox=-90,-180,90,180&width=1024&height=1024"),
         region="اقیانوس هند و خاورمیانه — پوشش ایران", cc="IR"),
]

FEEDS = [
    dict(key="hubble", sat="Hubble / NASA-ESA",
         urls=["https://feeds.feedburner.com/hubble_images/",
               "https://esahubble.org/images/rss/"]),
    dict(key="webb", sat="JWST / NASA-ESA",
         urls=["https://esawebb.org/images/rss/",
               "https://feeds.feedburner.com/webb_images/"]),
]

EPIC_API = "https://epic.gsfc.nasa.gov/api/natural"
EPIC_ARC = "https://epic.gsfc.nasa.gov/archive/natural/{y}/{m}/{d}/jpg/{img}.jpg"
HIMA_JSON = "https://himawari8-dl.nict.go.jp/himawari8/img/D531106/latest.json"
HIMA_IMG = ("https://himawari8-dl.nict.go.jp/himawari8/img/D531106/1d/550/"
            "{y}/{m}/{d}/{hm}_0_0.png")

COUNTRY = {"IR": "ایران", "US": "آمریکا", "CN": "چین", "IN": "هند", "RU": "روسیه",
           "BR": "برزیل", "AU": "استرالیا", "SA": "عربستان سعودی", "EG": "مصر",
           "TR": "ترکیه", "PK": "پاکستان", "ZA": "آفریقای جنوبی", "FR": "فرانسه",
           "DE": "آلمان", "GB": "بریتانیا", "JP": "ژاپن", "IQ": "عراق",
           "AF": "افغانستان", "OM": "عمان", "AE": "امارات", "QA": "قطر"}


def cc_to_region(lat, lon):
    cc = ""
    try:
        import reverse_geocoder as rg
        res = rg.search([(lat, lon)], mode=2, verbose=False)
        cc = res[0]["cc"] if res else ""
    except Exception as e:
        log.debug("geocode failed: %s", e)
    name = COUNTRY.get(cc, cc or "اقیانوس/نامشخص")
    return f"{name} — مرکز تصویر ({lat:.1f}°, {lon:.1f}°)", cc


async def _get(session, url, timeout=30, json_mode=False):
    try:
        async with session.get(url, headers=UA,
                               timeout=aiohttp.ClientTimeout(total=timeout)) as r:
            if r.status != 200:
                return None, None
            if json_mode:
                return await r.json(content_type=None), r.headers
            return await r.read(), r.headers
    except Exception as e:
        log.debug("GET %s failed: %s", url, e)
        return None, None


def _http_time(headers):
    lm = (headers or {}).get("Last-Modified")
    if lm:
        try:
            return parsedate_to_datetime(lm).timestamp()
        except Exception:
            pass
    return time.time()


async def handle_image(session, queue, *, src, url, sat, region, cc="",
                       lat=None, lon=None, img_time=None):
    data, headers = await _get(session, url)
    if not data or len(data) < 5000:
        return None
    h = hashlib.sha1(data).hexdigest()
    if db.image_exists(h):
        return None
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
        w, hh = im.size
    except Exception:
        return None  # not a valid/complete image at all -> skip
    if img_time is None:
        img_time = _http_time(headers)
    ext = ".png" if url.lower().split("?")[0].endswith(".png") else ".jpg"
    path = os.path.join(config.IMG_DIR, f"{int(time.time())}_{src}_{h[:8]}{ext}")
    with open(path, "wb") as f:
        f.write(data)
    partial = detect_partial(path)
    repaired = await asyncio.to_thread(try_repair, path) if partial else None
    img_id = db.insert_image(dict(
        src=src, url=url, hash=h, path=path, region=region, cc=cc, lat=lat, lon=lon,
        sat=sat, img_time=img_time, fetched_at=time.time(),
        status="partial" if partial else "complete",
        width=w, height=hh, size=len(data), repaired_path=repaired))
    log.info("NEW image %s partial=%s -> id=%s", src, partial, img_id)
    await queue.put((img_id, "new"))
    return img_id


async def poll_static(session, queue):
    for s in STATIC_SOURCES:
        try:
            await handle_image(session, queue, src=s["key"], url=s["url"],
                               sat=s["sat"], region=s["region"], cc=s["cc"])
        except Exception as e:
            log.warning("static %s failed: %s", s["key"], e)


async def poll_epic(session, queue):
    data, _ = await _get(session, EPIC_API, json_mode=True)
    if not data:
        return
    for item in data[:3]:  # newest few; dedup handles the rest
        try:
            d, t = item["date"].split(" ")
            y, m, dd = d.split("-")
            url = EPIC_ARC.format(y=y, m=m, d=dd, img=item["image"])
            img_time = calendar.timegm(time.strptime(item["date"], "%Y-%m-%d %H:%M:%S"))
            cen = item.get("centroid_coordinates") or {}
            lat, lon = cen.get("lat"), cen.get("lon")
            region, cc = ("زمین از دید DSCOVR", "")
            if lat is not None and lon is not None:
                region, cc = await asyncio.to_thread(cc_to_region, lat, lon)
            await handle_image(session, queue, src="epic", url=url,
                               sat="DSCOVR EPIC / NASA", region=region, cc=cc,
                               lat=lat, lon=lon, img_time=img_time)
        except Exception as e:
            log.warning("epic item failed: %s", e)


async def poll_himawari(session, queue):
    meta, _ = await _get(session, HIMA_JSON, json_mode=True)
    if not meta or "date" not in meta:
        return
    try:
        d, t = meta["date"].split(" ")
        y, m, dd = d.split("-")
        hm = t.replace(":", "")[:4] + "00"
        url = HIMA_IMG.format(y=y, m=m, d=dd, hm=hm)
        img_time = calendar.timegm(time.strptime(meta["date"], "%Y-%m-%d %H:%M:%S"))
        await handle_image(session, queue, src="himawari", url=url,
                           sat="Himawari-8/9 / JMA-NICT",
                           region="شرق آسیا و اقیانوسیه — ژاپن", cc="JP",
                           img_time=img_time)
    except Exception as e:
        log.warning("himawari failed: %s", e)


def _entry_image(e):
    for l in e.get("links", []):
        if str(l.get("type", "")).startswith("image"):
            return l.get("href")
    for m in e.get("media_content", []):
        if m.get("url"):
            return m["url"]
    html = ""
    if e.get("content"):
        html = e.content[0].get("value", "")
    elif e.get("summary"):
        html = e.summary
    m = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', html)
    return m.group(1) if m else None


async def poll_feeds(session, queue):
    import feedparser
    for feed in FEEDS:
        for fu in feed["urls"]:
            try:
                parsed = await asyncio.to_thread(feedparser.parse, fu)
                if not parsed.entries:
                    continue
                e = parsed.entries[0]
                img = _entry_image(e)
                if not img or not img.startswith("http"):
                    continue
                img_time = None
                if e.get("published_parsed"):
                    img_time = calendar.timegm(e.published_parsed)
                title = re.sub(r"\s+", " ", e.get("title", ""))[:70]
                await handle_image(session, queue, src=feed["key"], url=img,
                                   sat=feed["sat"],
                                   region=f"فضای عمیق — {title}",
                                   img_time=img_time)
                break  # this feed URL works, skip fallbacks
            except Exception as ex:
                log.debug("feed %s (%s) failed: %s", feed["key"], fu, ex)


async def recheck_partials(session, queue):
    """Re-download URLs of partial images; when the complete version
    arrives (different bytes + passes detection), update and resend."""
    for row in db.partials_due():
        try:
            data, headers = await _get(session, row["url"])
            if not data:
                db.update_image(row["id"], rechecks=row["rechecks"] + 1)
                continue
            h = hashlib.sha1(data).hexdigest()
            if h == row["hash"]:
                db.update_image(row["id"], rechecks=row["rechecks"] + 1)
                continue
            try:
                im = Image.open(io.BytesIO(data))
                im.load()
                w, hh = im.size
            except Exception:
                db.update_image(row["id"], rechecks=row["rechecks"] + 1)
                continue
            ext = os.path.splitext(row["path"])[1] or ".jpg"
            path = os.path.join(config.IMG_DIR,
                                f"{int(time.time())}_{row['src']}_full_{h[:8]}{ext}")
            with open(path, "wb") as f:
                f.write(data)
            if detect_partial(path):
                db.update_image(row["id"], rechecks=row["rechecks"] + 1)
                continue
            db.update_image(row["id"], hash=h + "_full", path=path, status="complete",
                            width=w, height=hh, size=len(data),
                            img_time=_http_time(headers))
            log.info("partial %s completed -> resend", row["id"])
            await queue.put((row["id"], "completed"))
        except Exception as e:
            log.debug("recheck failed: %s", e)


async def poll_loop(queue):
    await asyncio.sleep(3)
    async with aiohttp.ClientSession() as session:
        while True:
            t0 = time.time()
            for job in (poll_static, poll_epic, poll_himawari, poll_feeds,
                        recheck_partials):
                try:
                    await job(session, queue)
                except Exception as e:
                    log.warning("%s failed: %s", job.__name__, e)
            dt = time.time() - t0
            await asyncio.sleep(max(5, config.POLL_INTERVAL - dt))
