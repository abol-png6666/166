import sqlite3
import threading
import time
import config

_lock = threading.RLock()
_conn = None


def init(db_path=None):
    global _conn
    config.ensure_dirs()
    _conn = sqlite3.connect(db_path or config.DB_PATH, check_same_thread=False)
    _conn.row_factory = sqlite3.Row
    _conn.executescript("""
    CREATE TABLE IF NOT EXISTS config(k TEXT PRIMARY KEY, v TEXT);
    CREATE TABLE IF NOT EXISTS users(
        chat_id INTEGER PRIMARY KEY,
        lang TEXT DEFAULT 'fa',
        first_seen REAL);
    CREATE TABLE IF NOT EXISTS images(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        src TEXT, url TEXT, hash TEXT UNIQUE, path TEXT,
        region TEXT DEFAULT '', cc TEXT DEFAULT '',
        lat REAL, lon REAL,
        sat TEXT DEFAULT '',
        img_time REAL, fetched_at REAL,
        status TEXT DEFAULT 'complete',
        width INTEGER DEFAULT 0, height INTEGER DEFAULT 0,
        size INTEGER DEFAULT 0,
        repaired_path TEXT, rechecks INTEGER DEFAULT 0);
    CREATE INDEX IF NOT EXISTS idx_f ON images(fetched_at);
    """)
    _conn.commit()
    if cfg('first_run') is None:
        setcfg('first_run', str(time.time()))


def cfg(k, default=None):
    with _lock:
        r = _conn.execute("SELECT v FROM config WHERE k=?", (k,)).fetchone()
    return r['v'] if r else default


def setcfg(k, v):
    with _lock:
        _conn.execute("INSERT INTO config(k,v) VALUES(?,?) "
                      "ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))
        _conn.commit()


def ensure_user(chat_id):
    with _lock:
        _conn.execute("INSERT OR IGNORE INTO users(chat_id, lang, first_seen) VALUES(?,?,?)",
                      (chat_id, 'fa', time.time()))
        _conn.commit()


def get_users():
    with _lock:
        return _conn.execute("SELECT * FROM users").fetchall()


def get_user_lang(chat_id):
    with _lock:
        r = _conn.execute("SELECT lang FROM users WHERE chat_id=?", (chat_id,)).fetchone()
    return r['lang'] if r else 'fa'


def set_user_lang(chat_id, lang):
    with _lock:
        _conn.execute("UPDATE users SET lang=? WHERE chat_id=?", (lang, chat_id))
        _conn.commit()


def remove_user(chat_id):
    with _lock:
        _conn.execute("DELETE FROM users WHERE chat_id=?", (chat_id,))
        _conn.commit()


def image_exists(h):
    with _lock:
        return _conn.execute("SELECT 1 FROM images WHERE hash=?", (h,)).fetchone() is not None


def insert_image(d):
    cols = ','.join(d.keys())
    qs = ','.join('?' * len(d))
    with _lock:
        cur = _conn.execute(f"INSERT INTO images({cols}) VALUES({qs})", tuple(d.values()))
        _conn.commit()
        return cur.lastrowid


def get_image(img_id):
    with _lock:
        return _conn.execute("SELECT * FROM images WHERE id=?", (img_id,)).fetchone()


def update_image(img_id, **fields):
    sets = ','.join(f"{k}=?" for k in fields)
    with _lock:
        _conn.execute(f"UPDATE images SET {sets} WHERE id=?", (*fields.values(), img_id))
        _conn.commit()


def images_since(ts, limit=30):
    with _lock:
        return _conn.execute(
            "SELECT * FROM images WHERE fetched_at>=? ORDER BY fetched_at DESC LIMIT ?",
            (ts, limit)).fetchall()


def partials_due(limit=5, max_rechecks=40):
    with _lock:
        return _conn.execute(
            "SELECT * FROM images WHERE status='partial' AND rechecks<? "
            "AND fetched_at>? ORDER BY fetched_at ASC LIMIT ?",
            (max_rechecks, time.time() - 6 * 3600, limit)).fetchall()


def find_region(q):
    ql = q.strip().lower()
    with _lock:
        if ql in ('iran', 'ir', 'ایران', 'persia', 'فارس'):
            r = _conn.execute(
                "SELECT * FROM images WHERE cc='IR' OR region LIKE '%ایران%' "
                "OR (lat BETWEEN 24 AND 40 AND lon BETWEEN 43 AND 64) "
                "ORDER BY fetched_at DESC LIMIT 1").fetchone()
            if r:
                return r
        r = _conn.execute(
            "SELECT * FROM images WHERE UPPER(cc)=? ORDER BY fetched_at DESC LIMIT 1",
            (ql.upper(),)).fetchone()
        if r:
            return r
        return _conn.execute(
            "SELECT * FROM images WHERE LOWER(region) LIKE ? OR LOWER(sat) LIKE ? "
            "ORDER BY fetched_at DESC LIMIT 1", (f'%{ql}%', f'%{ql}%')).fetchone()


def counts():
    with _lock:
        u = _conn.execute("SELECT COUNT(*) c FROM users").fetchone()['c']
        i = _conn.execute("SELECT COUNT(*) c FROM images").fetchone()['c']
        p = _conn.execute("SELECT COUNT(*) c FROM images WHERE status='partial'").fetchone()['c']
    return u, i, p
