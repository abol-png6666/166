#!/usr/bin/env bash
# 🛰️ SpaceWatch Bot — راه‌اندازی روی VPS (اوبونتو/دبیان)
set -e

echo "🛰️  نصب بات رصد فضا..."

# 1) پیش‌نیازهای سیستمی
sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip curl

# 2) محیط مجازی پایتون + کتابخانه‌ها
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip -q
pip install -q -r requirements.txt

# 3) cloudflared (برای لینک دانلود مستقیم فایل‌های +49MB)
if ! command -v cloudflared >/dev/null 2>&1; then
  ARCH=$(uname -m)
  case "$ARCH" in
    x86_64)  CF=amd64 ;;
    aarch64) CF=arm64 ;;
    armv7l)  CF=arm ;;
    *)       CF=amd64 ;;
  esac
  echo "⬇️  دانلود cloudflared ($CF)..."
  curl -L -o cloudflared "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$CF"
  chmod +x cloudflared
  sudo mv cloudflared /usr/local/bin/cloudflared 2>/dev/null || true
fi

mkdir -p data/images data/files

echo ""
echo "✅ نصب کامل شد!"
echo "────────────────────────────────────────────"
echo "اجرای بات:"
echo "   source venv/bin/activate"
echo "   python main.py"
echo ""
echo "بعد مرورگر رو باز کن:  http://IP-سرور:8080"
echo "اونجا توکن بات (از @BotFather) و آیدی عددی ادمین رو وارد کن."
echo "آیدی عددیت رو از @userinfobot می‌تونی بگیری."
echo "────────────────────────────────────────────"
echo "💡 اجرای دائمی (اختیاری):"
echo "   nohup python main.py > data/out.log 2>&1 &"
