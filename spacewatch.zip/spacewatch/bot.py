"""Telegram bot layer: handlers, broadcasting, command menu."""
import asyncio
import hashlib
import logging
import os
import re
import time
import zipfile

from telegram import BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.error import Forbidden, TelegramError
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler,
                          ContextTypes)

import config
import database as db
import tunnel
from i18n import LANGS, tr

log = logging.getLogger("bot")

HIST_RE = re.compile(r"(\d+)\s*([mMhHdD])")
UNITS = {"m": 60, "h": 3600, "d": 86400}


# ---------- helpers ----------------------------------------------------------
def glass_buttons(img_id, lang):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(tr(lang, "orig_btn"), callback_data=f"orig:{img_id}"),
        InlineKeyboardButton(tr(lang, "rep_btn"), callback_data=f"rep:{img_id}"),
        InlineKeyboardButton(tr(lang, "info_btn"), callback_data=f"info:{img_id}"),
    ]])


def caption_for(img, lang):
    it = img["img_time"] or img["fetched_at"]
    delay = max(0, (img["fetched_at"] or time.time()) - it)
    delay_s = (f"{int(delay // 60)} {tr(lang, 'min')}" if delay >= 60
               else f"{int(delay)} {tr(lang, 'sec')}")
    st = tr(lang, "st_partial" if img["status"] == "partial" else "st_complete")
    return (f"🛰️ <b>{tr(lang, 'cap_title')}</b>\n"
            f"📍 {tr(lang, 'region')}: {img['region'] or '—'}\n"
            f"🕐 {tr(lang, 'time')}: {time.strftime('%H:%M', time.gmtime(it))} UTC\n"
            f"⏱️ {tr(lang, 'delay')}: {delay_s}\n"
            f"📡 {tr(lang, 'sat')}: {img['sat']}\n"
            f"🖼️ {tr(lang, 'quality')}: {img['width']}×{img['height']}\n"
            f"📦 {tr(lang, 'size')}: {img['size'] / 1024:.0f} KB\n"
            f"🔖 {tr(lang, 'status')}: {st}")


async def send_image(tgbot, chat_id, img, lang, kind="new"):
    cap = caption_for(img, lang)
    if kind == "completed":
        cap = tr(lang, "completed_follow") + "\n\n" + cap
    kb = glass_buttons(img["id"], lang)
    size = img["size"] or 0
    if size > config.MAX_TG_DOC:
        link = await tunnel.publish_file(img["path"])
        text = cap + "\n\n📦 " + (link or tr(lang, "no_tunnel"))
        await tgbot.send_message(chat_id, text, parse_mode="HTML",
                                 disable_web_page_preview=True)
    elif size > config.MAX_TG_PHOTO:
        with open(img["path"], "rb") as f:
            await tgbot.send_document(chat_id, f, caption=cap,
                                      parse_mode="HTML", reply_markup=kb)
    else:
        with open(img["path"], "rb") as f:
            await tgbot.send_photo(chat_id, f, caption=cap,
                                   parse_mode="HTML", reply_markup=kb)
    if img["repaired_path"] and kind == "new":
        try:
            with open(img["repaired_path"], "rb") as f:
                await tgbot.send_photo(chat_id, f,
                                       caption=tr(lang, "repaired_caption"))
        except Exception as e:
            log.debug("repaired send failed: %s", e)


def is_admin(chat_id):
    adm = db.cfg("admin_id")
    return adm is not None and str(chat_id) == str(adm)


def lang_of(chat_id):
    db.ensure_user(chat_id)
    return db.get_user_lang(chat_id)


def fmt_uptime(seconds, lang):
    m = int(seconds // 60)
    if m < 60:
        return f"{m} {tr(lang, 'min')}"
    h = m // 60
    if h < 48:
        return f"{h}H"
    return f"{h // 24}D"


# ---------- command handlers -------------------------------------------------
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_chat.id
    db.ensure_user(cid)
    kb = [[InlineKeyboardButton(f"{flag} {label}", callback_data=f"lang:{code}")
           for code, label, flag in LANGS[i:i + 2]]
          for i in range(0, len(LANGS), 2)]
    await update.message.reply_text(
        tr("fa", "choose_lang") + "\n" + tr("en", "choose_lang"),
        reply_markup=InlineKeyboardMarkup(kb))


async def on_lang(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    code = q.data.split(":", 1)[1]
    db.ensure_user(q.message.chat_id)
    db.set_user_lang(q.message.chat_id, code)
    await q.edit_message_text(tr(code, "lang_saved"))
    await q.message.reply_text(tr(code, "welcome"))
    await q.message.reply_text(tr(code, "help"), parse_mode="HTML")


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(tr(lang_of(update.effective_chat.id), "help"),
                                    parse_mode="HTML")


async def cmd_history(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    m = HIST_RE.search(update.message.text or "")
    if not m:
        await update.message.reply_text(tr(lang, "hist_usage"))
        return
    n, unit = int(m.group(1)), m.group(2).lower()
    delta = n * UNITS[unit]
    first_run = float(db.cfg("first_run") or time.time())
    if time.time() - first_run < delta:
        await update.message.reply_text(
            tr(lang, "uptime_less").format(have=fmt_uptime(time.time() - first_run, lang)))
    rows = db.images_since(time.time() - delta)
    if not rows:
        await update.message.reply_text(tr(lang, "hist_none"))
        return
    for img in reversed(rows):  # oldest first
        try:
            await send_image(ctx.bot, cid, img, lang)
        except TelegramError as e:
            log.debug("history send: %s", e)


async def cmd_region(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    q = " ".join(ctx.args or []).strip()
    if not q:
        await update.message.reply_text(tr(lang, "region_usage"))
        return
    row = db.find_region(q)
    if not row:
        await update.message.reply_text(tr(lang, "region_none"))
        return
    await send_image(ctx.bot, cid, row, lang)


def _build_zip():
    zpath = os.path.join(config.FILE_DIR, f"all_images_{int(time.time())}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(os.listdir(config.IMG_DIR)):
            z.write(os.path.join(config.IMG_DIR, f), f)
    return zpath


async def cmd_all(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    if not is_admin(cid):
        await update.message.reply_text(tr(lang, "admin_only"))
        return
    await update.message.reply_text(tr(lang, "all_wait"))
    zpath = await asyncio.to_thread(_build_zip)
    size = os.path.getsize(zpath)
    if size > config.MAX_TG_DOC:
        link = await tunnel.publish_file(zpath, "all_images.zip")
        await update.message.reply_text(
            tr(lang, "all_big") + "\n" + (link or tr(lang, "no_tunnel")))
    else:
        with open(zpath, "rb") as f:
            await ctx.bot.send_document(cid, f, filename="all_images.zip")


async def cmd_public(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    if not is_admin(cid):
        await update.message.reply_text(tr(lang, "admin_only"))
        return
    cur = db.cfg("public", "0") == "1"
    arg = (ctx.args[0].lower() if ctx.args else "")
    new = (arg in ("on", "1", "روشن")) if arg else not cur
    db.setcfg("public", "1" if new else "0")
    await update.message.reply_text(tr(lang, "public_on" if new else "public_off"))


async def cmd_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    if not is_admin(cid):
        await update.message.reply_text(tr(lang, "admin_only"))
        return
    text = (update.message.text or "").split(None, 1)
    if len(text) < 2:
        await update.message.reply_text("/broadcast <text>")
        return
    n = await broadcast_text(ctx.bot, text[1])
    await update.message.reply_text(tr(lang, "broadcast_done").format(n=n))


async def broadcast_text(tgbot, text):
    n = 0
    for u in db.get_users():
        try:
            await tgbot.send_message(u["chat_id"], text)
            n += 1
        except Forbidden:
            db.remove_user(u["chat_id"])
        except TelegramError:
            pass
    return n


# ---------- inline buttons ---------------------------------------------------
async def on_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    cid = q.message.chat_id
    lang = lang_of(cid)
    action, img_id = q.data.split(":", 1)
    img = db.get_image(int(img_id))
    if not img:
        await q.answer("not found", show_alert=True)
        return
    if action == "info":
        txt = (f"🛰️ {img['sat']}\n📍 {img['region']}\n🔗 {img['url']}\n"
               f"🧬 {img['hash'][:12]}…  •  {img['width']}×{img['height']}"
               f"  •  {img['size'] / 1024:.0f} KB")
        await q.answer(txt[:190], show_alert=True)
    elif action == "rep":
        if img["repaired_path"] and os.path.exists(img["repaired_path"]):
            await q.answer()
            with open(img["repaired_path"], "rb") as f:
                await ctx.bot.send_photo(cid, f,
                                         caption=tr(lang, "repaired_caption"))
        else:
            await q.answer(tr(lang, "no_repaired"), show_alert=True)
    elif action == "orig":
        await q.answer()
        if (img["size"] or 0) > config.MAX_TG_DOC:
            link = await tunnel.publish_file(img["path"])
            await q.message.reply_text(link or tr(lang, "no_tunnel"))
        else:
            with open(img["path"], "rb") as f:
                await ctx.bot.send_document(cid, f,
                                            filename=os.path.basename(img["path"]))


# ---------- manager ----------------------------------------------------------
class BotManager:
    def __init__(self, queue):
        self.queue = queue
        self.app = None
        self._bc = None
        self.running = False

    async def start(self):
        if self.running:
            return True
        token = db.cfg("bot_token")
        if not token:
            return False
        self.app = Application.builder().token(token).build()
        self._register(self.app)
        await self.app.initialize()
        try:
            await self.app.bot.set_my_commands([
                BotCommand("start", "🚀 شروع / Start"),
                BotCommand("help", "📚 راهنما / Help"),
                BotCommand("history", "🕐 تصاویر گذشته — /history 6H"),
                BotCommand("region", "📍 آخرین تصویر منطقه — /region iran"),
                BotCommand("all", "🗂 همه تصاویر (ادمین)"),
                BotCommand("public", "🌍 حالت عمومی (ادمین)"),
                BotCommand("broadcast", "📣 پیام همگانی (ادمین)"),
            ])
        except TelegramError as e:
            log.debug("set_my_commands: %s", e)
        await self.app.start()
        await self.app.updater.start_polling(drop_pending_updates=True)
        self._bc = asyncio.create_task(self._broadcaster())
        self.running = True
        log.info("telegram bot started")
        return True

    async def stop(self):
        if not self.running:
            return
        if self._bc:
            self._bc.cancel()
        try:
            await self.app.updater.stop()
            await self.app.stop()
            await self.app.shutdown()
        except Exception as e:
            log.debug("stop: %s", e)
        self.app = None
        self.running = False
        log.info("telegram bot stopped")

    def _register(self, app):
        app.add_handler(CommandHandler("start", cmd_start))
        app.add_handler(CommandHandler("help", cmd_help))
        app.add_handler(CommandHandler("history", cmd_history))
        app.add_handler(CommandHandler("region", cmd_region))
        app.add_handler(CommandHandler("all", cmd_all))
        app.add_handler(CommandHandler("public", cmd_public))
        app.add_handler(CommandHandler("broadcast", cmd_broadcast))
        app.add_handler(CallbackQueryHandler(on_lang, pattern=r"^lang:"))
        app.add_handler(CallbackQueryHandler(on_button, pattern=r"^(orig|rep|info):"))

    async def _broadcaster(self):
        while True:
            try:
                img_id, kind = await self.queue.get()
                img = db.get_image(img_id)
                if not img or not self.app:
                    continue
                public = db.cfg("public", "0") == "1"
                users = db.get_users() if public else []
                targets = {u["chat_id"]: u["lang"] for u in users}
                adm = db.cfg("admin_id")
                if adm:
                    targets.setdefault(int(adm), db.get_user_lang(int(adm)))
                for cid, lang in targets.items():
                    try:
                        await send_image(self.app.bot, cid, img, lang, kind)
                    except Forbidden:
                        db.remove_user(cid)
                    except Exception as e:
                        log.debug("send to %s failed: %s", cid, e)
                    await asyncio.sleep(0.05)  # stay well under rate limits
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("broadcaster: %s", e)
                await asyncio.sleep(1)
