"""10-language UI strings. Fallback: requested lang -> en -> key."""

LANGS = [
    ("fa", "فارسی", "🇮🇷"), ("en", "English", "🇬🇧"), ("ar", "العربية", "🇸🇦"),
    ("tr", "Türkçe", "🇹🇷"), ("ru", "Русский", "🇷🇺"), ("zh", "中文", "🇨🇳"),
    ("es", "Español", "🇪🇸"), ("fr", "Français", "🇫🇷"), ("de", "Deutsch", "🇩🇪"),
    ("ja", "日本語", "🇯🇵"),
]

T = {
"fa": {
 "choose_lang": "🌐 زبان خود را انتخاب کنید:",
 "lang_saved": "✅ زبان ذخیره شد: فارسی",
 "welcome": "سلام! 👋 به «رصد فضا» خوش اومدی.\nاز این لحظه جدیدترین تصاویر ماهواره‌ها و تلسکوپ‌های فضایی به‌محض انتشار از منابع رسمی اینجا میاد. 🛰️",
 "help": ("🛰️ <b>راهنمای بات رصد فضا</b>\n\n"
          "این بات جدیدترین تصاویر ماهواره‌های هواشناسی (GOES، Meteosat، Himawari)، خورشید (SDO، SOHO)، "
          "دوربین EPIC و تلسکوپ‌های Hubble و JWST را از منابع رسمی، لحظه‌ای که منتشر می‌شوند دریافت و می‌فرستد.\n\n"
          "مسیر هر تصویر:\n🛰️ تصویر جدید → بررسی → پردازش → ارسال تلگرام\n\n"
          "📌 <b>دستورها:</b>\n"
          "/history 6H — تصاویر ۶ ساعت گذشته (M=دقیقه، H=ساعت، D=روز)\n"
          "/region iran — آخرین تصویر مربوط به یک منطقه/کشور\n"
          "/all — همه تصاویر در یک فایل ZIP (ادمین)\n"
          "/public — روشن/خاموش کردن ارسال عمومی (ادمین)\n"
          "/broadcast متن — پیام همگانی (ادمین)\n"
          "/help — همین راهنما\n\n"
          "⚙️ <b>نکات:</b>\n"
          "• تصاویر تکراری ارسال نمی‌شوند.\n"
          "• تصاویر ناقص بلافاصله می‌آیند؛ نسخه ترمیم‌شده و سپس نسخه کامل هم بعداً ارسال می‌شود.\n"
          "• فایل‌های بالای ۴۹ مگابایت با لینک دانلود مستقیم موقت (Cloudflare Tunnel) می‌آیند.\n"
          "• پاسخ دستورها محلی و زیر یک میلی‌ثانیه است."),
 "cap_title": "تصویر جدید",
 "region": "منطقه", "time": "زمان تصویربرداری", "delay": "تأخیر دریافت",
 "sat": "ماهواره", "quality": "کیفیت", "size": "حجم", "status": "وضعیت",
 "st_complete": "✅ کامل", "st_partial": "⚠️ ناقص (نسخه کامل بعداً می‌آید)",
 "min": "دقیقه", "sec": "ثانیه",
 "hist_none": "📭 در این بازه تصویری ثبت نشده.",
 "hist_usage": "مثال: /history 6H یا /history 2D یا /history 30M",
 "uptime_less": "ℹ️ بات فقط {have} فعال بوده و هنوز به‌اندازه بازه درخواستی کار نکرده؛ این موارد موجود است:",
 "region_none": "📭 تصویری برای این منطقه پیدا نشد.",
 "region_usage": "مثال: /region iran",
 "admin_only": "⛔ این دستور فقط برای ادمین است.",
 "all_wait": "⏳ در حال ساخت فایل ZIP از همه تصاویر...",
 "all_big": "📦 حجم فایل بیش از ۴۹ مگابایت است؛ لینک دانلود مستقیم موقت:",
 "no_tunnel": "⚠️ cloudflared روی سرور نصب نیست؛ فایل در سرور ذخیره شد.",
 "public_on": "🌍 حالت عمومی روشن شد — تصاویر برای همه کاربران ارسال می‌شود.",
 "public_off": "🔒 حالت عمومی خاموش شد — فقط ادمین دریافت می‌کند.",
 "broadcast_done": "📣 پیام برای {n} کاربر ارسال شد.",
 "orig_btn": "🔗 فایل اصلی", "rep_btn": "🛠 نسخه ترمیم‌شده", "info_btn": "ℹ️ جزئیات",
 "no_repaired": "نسخه ترمیم‌شده برای این تصویر موجود نیست.",
 "completed_follow": "✅ نسخه کاملِ تصویر ناقص قبلی رسید",
 "repaired_caption": "🛠 نسخه ترمیم‌شده خودکار (OpenCV)",
},
"en": {
 "choose_lang": "🌐 Choose your language:",
 "lang_saved": "✅ Language saved: English",
 "welcome": "Hi! 👋 Welcome to SpaceWatch.\nFrom now on, the newest satellite & space-telescope images arrive here the moment they're published. 🛰️",
 "help": ("🛰️ <b>SpaceWatch Bot Help</b>\n\n"
          "Fresh imagery from weather satellites (GOES, Meteosat, Himawari), the Sun (SDO, SOHO), "
          "NASA EPIC and the Hubble / JWST telescopes — fetched from official sources the moment it's published.\n\n"
          "Pipeline: 🛰️ New image → Check → Process → Telegram\n\n"
          "📌 <b>Commands:</b>\n"
          "/history 6H — images of the last 6 hours (M/H/D)\n"
          "/region iran — latest image of a region/country\n"
          "/all — all images as one ZIP (admin)\n"
          "/public — toggle public broadcast (admin)\n"
          "/broadcast text — message all users (admin)\n\n"
          "⚙️ Duplicates are skipped • partial images are sent instantly, then repaired & complete versions • "
          "files >49MB arrive as a temporary direct-download link • commands answer locally in under 1ms."),
 "cap_title": "New image",
 "region": "Region", "time": "Capture time", "delay": "Fetch delay",
 "sat": "Satellite", "quality": "Quality", "size": "Size", "status": "Status",
 "st_complete": "✅ Complete", "st_partial": "⚠️ Partial (complete version follows)",
 "min": "min", "sec": "s",
 "hist_none": "📭 No images in this window.",
 "hist_usage": "Example: /history 6H or /history 2D or /history 30M",
 "uptime_less": "ℹ️ The bot has only been up for {have}; here's everything so far:",
 "region_none": "📭 No image found for that region.",
 "region_usage": "Example: /region iran",
 "admin_only": "⛔ Admin only.",
 "all_wait": "⏳ Building a ZIP of all images...",
 "all_big": "📦 File exceeds 49MB; temporary direct-download link:",
 "no_tunnel": "⚠️ cloudflared not installed; file stored on the server.",
 "public_on": "🌍 Public mode ON — images go to all users.",
 "public_off": "🔒 Public mode OFF — admin only.",
 "broadcast_done": "📣 Sent to {n} users.",
 "orig_btn": "🔗 Original file", "rep_btn": "🛠 Repaired", "info_btn": "ℹ️ Details",
 "no_repaired": "No repaired version for this image.",
 "completed_follow": "✅ Complete version of the earlier partial image",
 "repaired_caption": "🛠 Auto-repaired version (OpenCV)",
},
"ar": {
 "lang_saved": "✅ تم حفظ اللغة: العربية",
 "welcome": "مرحباً! 👋 أحدث صور الأقمار الصناعية والتلسكوبات الفضائية تصلك فور نشرها. 🛰️",
 "help": "🛰️ الأوامر:\n/history 6H صور آخر ٦ ساعات\n/region iran آخر صورة لمنطقة\n/all كل الصور (للمشرف)\n/public النشر العام\n/broadcast رسالة جماعية",
 "cap_title": "صورة جديدة", "region": "المنطقة", "time": "وقت الالتقاط", "delay": "التأخير",
 "sat": "القمر الصناعي", "quality": "الجودة", "size": "الحجم", "status": "الحالة",
 "st_complete": "✅ كاملة", "st_partial": "⚠️ ناقصة", "min": "دقيقة", "sec": "ثانية",
 "hist_none": "📭 لا صور.", "uptime_less": "ℹ️ البوت يعمل منذ {have} فقط:",
 "region_none": "📭 لا توجد صورة لهذه المنطقة.", "admin_only": "⛔ للمشرف فقط.",
 "all_wait": "⏳ جارٍ إنشاء ZIP...", "all_big": "📦 الملف أكبر من 49MB، رابط التحميل:",
 "broadcast_done": "📣 أُرسلت إلى {n}.",
 "orig_btn": "🔗 الأصل", "rep_btn": "🛠 المرمّمة", "info_btn": "ℹ️ تفاصيل",
 "completed_follow": "✅ وصلت النسخة الكاملة", "repaired_caption": "🛠 نسخة مرمّمة تلقائياً",
},
"tr": {
 "lang_saved": "✅ Dil kaydedildi: Türkçe",
 "welcome": "Merhaba! 👋 En yeni uydu ve uzay teleskobu görüntüleri yayınlanır yayınlanmaz burada. 🛰️",
 "help": "🛰️ Komutlar:\n/history 6H son 6 saatin görüntüleri\n/region iran bir bölgenin son görüntüsü\n/all tüm görüntüler (yönetici)\n/public herkese yayın\n/broadcast toplu mesaj",
 "cap_title": "Yeni görüntü", "region": "Bölge", "time": "Çekim zamanı", "delay": "Gecikme",
 "sat": "Uydu", "quality": "Kalite", "size": "Boyut", "status": "Durum",
 "st_complete": "✅ Tam", "st_partial": "⚠️ Eksik", "min": "dk", "sec": "sn",
 "hist_none": "📭 Görüntü yok.", "uptime_less": "ℹ️ Bot yalnızca {have} çalışıyor:",
 "region_none": "📭 Bu bölge için görüntü yok.", "admin_only": "⛔ Yalnızca yönetici.",
 "all_wait": "⏳ ZIP hazırlanıyor...", "all_big": "📦 Dosya 49MB üstü, indirme bağlantısı:",
 "broadcast_done": "📣 {n} kullanıcıya gönderildi.",
 "orig_btn": "🔗 Orijinal", "rep_btn": "🛠 Onarılmış", "info_btn": "ℹ️ Detay",
 "completed_follow": "✅ Tam sürüm geldi", "repaired_caption": "🛠 Otomatik onarılmış sürüm",
},
"ru": {
 "lang_saved": "✅ Язык сохранён: русский",
 "welcome": "Привет! 👋 Новейшие снимки спутников и космических телескопов — сразу после публикации. 🛰️",
 "help": "🛰️ Команды:\n/history 6H снимки за 6 часов\n/region iran последний снимок региона\n/all все снимки (админ)\n/public публичная рассылка\n/broadcast рассылка",
 "cap_title": "Новый снимок", "region": "Регион", "time": "Время съёмки", "delay": "Задержка",
 "sat": "Спутник", "quality": "Качество", "size": "Размер", "status": "Статус",
 "st_complete": "✅ Полный", "st_partial": "⚠️ Частичный", "min": "мин", "sec": "с",
 "hist_none": "📭 Нет снимков.", "uptime_less": "ℹ️ Бот работает только {have}:",
 "region_none": "📭 Снимок региона не найден.", "admin_only": "⛔ Только админ.",
 "all_wait": "⏳ Создаю ZIP...", "all_big": "📦 Файл больше 49МБ, ссылка:",
 "broadcast_done": "📣 Отправлено {n} пользователям.",
 "orig_btn": "🔗 Оригинал", "rep_btn": "🛠 Восстановл.", "info_btn": "ℹ️ Детали",
 "completed_follow": "✅ Полная версия получена", "repaired_caption": "🛠 Автовосстановленная версия",
},
"zh": {
 "lang_saved": "✅ 语言已保存：中文",
 "welcome": "你好！👋 最新的卫星与太空望远镜图像一经发布就会推送到这里。🛰️",
 "help": "🛰️ 命令：\n/history 6H 最近6小时图像\n/region iran 某地区最新图像\n/all 全部图像（管理员）\n/public 公开推送\n/broadcast 群发消息",
 "cap_title": "新图像", "region": "区域", "time": "拍摄时间", "delay": "延迟",
 "sat": "卫星", "quality": "质量", "size": "大小", "status": "状态",
 "st_complete": "✅ 完整", "st_partial": "⚠️ 不完整", "min": "分钟", "sec": "秒",
 "hist_none": "📭 暂无图像。", "uptime_less": "ℹ️ 机器人仅运行了 {have}：",
 "region_none": "📭 未找到该区域图像。", "admin_only": "⛔ 仅限管理员。",
 "all_wait": "⏳ 正在打包 ZIP...", "all_big": "📦 文件超过49MB，下载链接：",
 "broadcast_done": "📣 已发送给 {n} 位用户。",
 "orig_btn": "🔗 原图", "rep_btn": "🛠 修复版", "info_btn": "ℹ️ 详情",
 "completed_follow": "✅ 完整版本已到达", "repaired_caption": "🛠 自动修复版本",
},
"es": {
 "lang_saved": "✅ Idioma guardado: español",
 "welcome": "¡Hola! 👋 Las imágenes más recientes de satélites y telescopios espaciales llegan aquí al publicarse. 🛰️",
 "help": "🛰️ Comandos:\n/history 6H imágenes de las últimas 6 horas\n/region iran última imagen de una región\n/all todas las imágenes (admin)\n/public difusión pública\n/broadcast mensaje a todos",
 "cap_title": "Nueva imagen", "region": "Región", "time": "Hora de captura", "delay": "Retraso",
 "sat": "Satélite", "quality": "Calidad", "size": "Tamaño", "status": "Estado",
 "st_complete": "✅ Completa", "st_partial": "⚠️ Parcial", "min": "min", "sec": "s",
 "hist_none": "📭 Sin imágenes.", "uptime_less": "ℹ️ El bot solo lleva {have} activo:",
 "region_none": "📭 Sin imagen de esa región.", "admin_only": "⛔ Solo admin.",
 "all_wait": "⏳ Creando ZIP...", "all_big": "📦 Archivo >49MB, enlace de descarga:",
 "broadcast_done": "📣 Enviado a {n} usuarios.",
 "orig_btn": "🔗 Original", "rep_btn": "🛠 Reparada", "info_btn": "ℹ️ Detalles",
 "completed_follow": "✅ Versión completa recibida", "repaired_caption": "🛠 Versión reparada",
},
"fr": {
 "lang_saved": "✅ Langue enregistrée : français",
 "welcome": "Salut ! 👋 Les dernières images satellites et télescopes spatiaux arrivent ici dès publication. 🛰️",
 "help": "🛰️ Commandes :\n/history 6H images des 6 dernières heures\n/region iran dernière image d'une région\n/all toutes les images (admin)\n/public diffusion publique\n/broadcast message global",
 "cap_title": "Nouvelle image", "region": "Région", "time": "Heure de capture", "delay": "Délai",
 "sat": "Satellite", "quality": "Qualité", "size": "Taille", "status": "Statut",
 "st_complete": "✅ Complète", "st_partial": "⚠️ Partielle", "min": "min", "sec": "s",
 "hist_none": "📭 Aucune image.", "uptime_less": "ℹ️ Le bot n'est actif que depuis {have} :",
 "region_none": "📭 Aucune image pour cette région.", "admin_only": "⛔ Admin uniquement.",
 "all_wait": "⏳ Création du ZIP...", "all_big": "📦 Fichier >49Mo, lien de téléchargement :",
 "broadcast_done": "📣 Envoyé à {n} utilisateurs.",
 "orig_btn": "🔗 Original", "rep_btn": "🛠 Réparée", "info_btn": "ℹ️ Détails",
 "completed_follow": "✅ Version complète reçue", "repaired_caption": "🛠 Version réparée auto",
},
"de": {
 "lang_saved": "✅ Sprache gespeichert: Deutsch",
 "welcome": "Hallo! 👋 Die neuesten Satelliten- und Weltraumteleskop-Bilder kommen hier sofort nach Veröffentlichung an. 🛰️",
 "help": "🛰️ Befehle:\n/history 6H Bilder der letzten 6 Stunden\n/region iran neuestes Bild einer Region\n/all alle Bilder (Admin)\n/public öffentlicher Versand\n/broadcast Nachricht an alle",
 "cap_title": "Neues Bild", "region": "Region", "time": "Aufnahmezeit", "delay": "Verzögerung",
 "sat": "Satellit", "quality": "Qualität", "size": "Größe", "status": "Status",
 "st_complete": "✅ Vollständig", "st_partial": "⚠️ Unvollständig", "min": "Min", "sec": "s",
 "hist_none": "📭 Keine Bilder.", "uptime_less": "ℹ️ Der Bot läuft erst {have}:",
 "region_none": "📭 Kein Bild für diese Region.", "admin_only": "⛔ Nur Admin.",
 "all_wait": "⏳ ZIP wird erstellt...", "all_big": "📦 Datei >49MB, Download-Link:",
 "broadcast_done": "📣 An {n} Nutzer gesendet.",
 "orig_btn": "🔗 Original", "rep_btn": "🛠 Repariert", "info_btn": "ℹ️ Details",
 "completed_follow": "✅ Vollständige Version eingetroffen", "repaired_caption": "🛠 Auto-reparierte Version",
},
"ja": {
 "lang_saved": "✅ 言語を保存しました：日本語",
 "welcome": "こんにちは！👋 衛星・宇宙望遠鏡の最新画像が公開され次第ここに届きます。🛰️",
 "help": "🛰️ コマンド：\n/history 6H 過去6時間の画像\n/region iran 地域の最新画像\n/all 全画像（管理者）\n/public 公開配信\n/broadcast 一斉送信",
 "cap_title": "新しい画像", "region": "地域", "time": "撮影時刻", "delay": "遅延",
 "sat": "衛星", "quality": "品質", "size": "サイズ", "status": "状態",
 "st_complete": "✅ 完全", "st_partial": "⚠️ 不完全", "min": "分", "sec": "秒",
 "hist_none": "📭 画像がありません。", "uptime_less": "ℹ️ 稼働時間は {have} のみ：",
 "region_none": "📭 その地域の画像がありません。", "admin_only": "⛔ 管理者のみ。",
 "all_wait": "⏳ ZIP作成中...", "all_big": "📦 49MB超のためダウンロードリンク：",
 "broadcast_done": "📣 {n}人に送信しました。",
 "orig_btn": "🔗 原本", "rep_btn": "🛠 修復版", "info_btn": "ℹ️ 詳細",
 "completed_follow": "✅ 完全版が届きました", "repaired_caption": "🛠 自動修復バージョン",
},
}


def tr(lang, key):
    return T.get(lang, {}).get(key) or T["en"].get(key) or key
