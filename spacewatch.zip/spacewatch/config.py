import os

POLL_INTERVAL = 30                 # seconds (user choice)
MAX_TG_PHOTO = 10 * 1024 * 1024    # sendPhoto limit -> above this use document
MAX_TG_DOC = 49 * 1024 * 1024      # above this -> cloudflared direct link
WEB_PORT = 8080
FILE_PORT = 8090
IMG_DIR = "data/images"
FILE_DIR = "data/files"
DB_PATH = "data/bot.db"


def ensure_dirs():
    os.makedirs(IMG_DIR, exist_ok=True)
    os.makedirs(FILE_DIR, exist_ok=True)
