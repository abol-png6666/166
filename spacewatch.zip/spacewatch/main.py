"""SpaceWatch Bot — entry point.
Runs: Telegram bot + polling engine + web UI (:8080) + file server (:8090)."""
import asyncio
import logging

from aiohttp import web

import config
import database as db
from bot import BotManager
from sources import poll_loop
from tunnel import file_app
from webui import make_app


def setup_logging():
    config.ensure_dirs()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        handlers=[logging.StreamHandler(),
                  logging.FileHandler("data/bot.log", encoding="utf-8")])


async def main():
    setup_logging()
    log = logging.getLogger("main")
    db.init()

    queue = asyncio.Queue()
    mgr = BotManager(queue)

    # web UI on 8080
    ui = make_app(mgr)
    runner = web.AppRunner(ui)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", config.WEB_PORT).start()

    # local file server for cloudflared (big files), localhost only
    frunner = web.AppRunner(file_app())
    await frunner.setup()
    await web.TCPSite(frunner, "127.0.0.1", config.FILE_PORT).start()

    # image polling engine
    asyncio.create_task(poll_loop(queue))

    # auto-start bot if already configured
    if db.cfg("bot_token"):
        try:
            await mgr.start()
        except Exception as e:
            log.error("autostart failed: %s", e)

    log.info("Web UI:  http://0.0.0.0:%s", config.WEB_PORT)
    await asyncio.Event().wait()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
